import { Chatbot } from "@/components/ui/Chatbot";

export default function ChatbotSamplePage() {
  return (
    <div className="min-h-screen bg-paper flex flex-col items-center justify-center p-8 text-graphite-900 font-sans relative">
      <div className="max-w-3xl w-full text-center space-y-6">
        <h1 className="text-4xl md:text-5xl font-bold font-heading text-ink tracking-tight">
          AI Assistant Preview
        </h1>
        <p className="text-lg text-graphite-500 max-w-xl mx-auto">
          Interact with the chat widget in the bottom right corner. You can toggle between 
          <span className="font-medium text-accent-buyer px-1">Buyer Mode</span> and 
          <span className="font-medium text-accent-supplier px-1">Supplier Mode</span> 
          to see how the chatbot adapts its context.
        </p>
        
        <div className="pt-12 text-left bg-stone-100 p-8 rounded-card border border-stone-300 shadow-card">
          <h2 className="text-xl font-semibold mb-4 text-ink">Things to try:</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h3 className="font-medium text-accent-buyer flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-accent-buyer block"></span>
                In Buyer Mode
              </h3>
              <ul className="text-sm text-graphite-700 list-disc pl-5 space-y-1">
                <li>Ask about "cheapest available stock"</li>
                <li>Ask about "stock availability"</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-medium text-accent-supplier flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-accent-supplier block"></span>
                In Supplier Mode
              </h3>
              <ul className="text-sm text-graphite-700 list-disc pl-5 space-y-1">
                <li>Ask about "current market price"</li>
                <li>Ask about "market demand"</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* The Chatbot Component */}
      <Chatbot />
    </div>
  );
}
