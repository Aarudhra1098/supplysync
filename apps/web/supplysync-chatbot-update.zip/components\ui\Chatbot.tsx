"use client";

import { useState, useRef, useEffect } from "react";
import { MessageSquare, X, Send, User, Bot, ArrowRightLeft } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type Mode = "buyer" | "supplier";
type Message = { id: string; text: string; sender: "user" | "bot" };

const MOCK_RESPONSES = {
  buyer: {
    cheapest: "I found 3 suppliers with low-priced stock for you:\n1. GlobalTrade Co. - ₹375/unit (10k units available)\n2. Prime Materials - ₹385/unit (5k units available)\n3. Alpha Supply - ₹390/unit (20k units available)",
    stock: "We currently track over 150 suppliers with active stock in your preferred categories. Would you like to filter by location or price?",
    default: "I am your Buyer Assistant. I can help you locate the cheapest available stocks and negotiate bulk rates. Try asking me about 'cheapest stock' or 'available stock'.",
  },
  supplier: {
    price: "The current average market price for this product category is ₹405/unit. \n\nTo remain competitive while maximizing profit, we recommend pricing your product between ₹390 and ₹415 per unit.",
    market: "Market demand is currently High. Competitors are holding steady at around ₹400/unit. Now is a good time to list your inventory.",
    default: "I am your Supplier Assistant. I can help you analyze market prices so you can price your products competitively. Try asking about 'market price' or 'market demand'.",
  }
};

function generateId() {
  return Math.random().toString(36).substr(2, 9);
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<Mode>("buyer");
  
  // Separate message state for buyer and supplier
  const [buyerMessages, setBuyerMessages] = useState<Message[]>([]);
  const [supplierMessages, setSupplierMessages] = useState<Message[]>([]);
  const [hasHydrated, setHasHydrated] = useState(false);
  
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load from LocalStorage on mount
  useEffect(() => {
    const savedBuyer = localStorage.getItem("supplysync_chat_buyer");
    if (savedBuyer) {
      setBuyerMessages(JSON.parse(savedBuyer));
    } else {
      setBuyerMessages([{ id: generateId(), text: MOCK_RESPONSES.buyer.default, sender: "bot" }]);
    }

    const savedSupplier = localStorage.getItem("supplysync_chat_supplier");
    if (savedSupplier) {
      setSupplierMessages(JSON.parse(savedSupplier));
    } else {
      setSupplierMessages([{ id: generateId(), text: MOCK_RESPONSES.supplier.default, sender: "bot" }]);
    }
    
    const savedMode = localStorage.getItem("supplysync_chat_mode") as Mode;
    if (savedMode === "buyer" || savedMode === "supplier") {
      setMode(savedMode);
    }

    setHasHydrated(true);
  }, []);

  // Save Buyer Messages to LocalStorage
  useEffect(() => {
    if (hasHydrated && buyerMessages.length > 0) {
      localStorage.setItem("supplysync_chat_buyer", JSON.stringify(buyerMessages));
    }
  }, [buyerMessages, hasHydrated]);

  // Save Supplier Messages to LocalStorage
  useEffect(() => {
    if (hasHydrated && supplierMessages.length > 0) {
      localStorage.setItem("supplysync_chat_supplier", JSON.stringify(supplierMessages));
    }
  }, [supplierMessages, hasHydrated]);

  // Save Mode to LocalStorage
  useEffect(() => {
    if (hasHydrated) {
      localStorage.setItem("supplysync_chat_mode", mode);
    }
  }, [mode, hasHydrated]);

  const activeMessages = mode === "buyer" ? buyerMessages : supplierMessages;

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeMessages, isOpen]);

  // Handle mode toggle
  const toggleMode = () => {
    setMode(prev => prev === "buyer" ? "supplier" : "buyer");
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = { id: generateId(), text: inputValue.trim(), sender: "user" };
    
    if (mode === "buyer") {
      setBuyerMessages(prev => [...prev, userMessage]);
    } else {
      setSupplierMessages(prev => [...prev, userMessage]);
    }
    
    setInputValue("");

    // Mock AI response delay
    setTimeout(() => {
      const lowerInput = userMessage.text.toLowerCase();
      let botResponse = MOCK_RESPONSES[mode].default;

      if (mode === "buyer") {
        if (lowerInput.includes("cheap") || lowerInput.includes("price") || lowerInput.includes("lowest")) {
          botResponse = MOCK_RESPONSES.buyer.cheapest;
        } else if (lowerInput.includes("stock") || lowerInput.includes("inventory")) {
          botResponse = MOCK_RESPONSES.buyer.stock;
        }
      } else {
        if (lowerInput.includes("price") || lowerInput.includes("rate") || lowerInput.includes("how much")) {
          botResponse = MOCK_RESPONSES.supplier.price;
        } else if (lowerInput.includes("market") || lowerInput.includes("demand")) {
          botResponse = MOCK_RESPONSES.supplier.market;
        }
      }

      const botMessage: Message = { id: generateId(), text: botResponse, sender: "bot" };
      
      if (mode === "buyer") {
        setBuyerMessages(prev => [...prev, botMessage]);
      } else {
        setSupplierMessages(prev => [...prev, botMessage]);
      }
    }, 600);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSend();
    }
  };

  // Prevent hydration mismatch by not rendering chat content until loaded
  if (!hasHydrated) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans">
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="mb-4 w-[350px] sm:w-[400px] bg-paper border border-stone-300 rounded-2xl shadow-card-hover overflow-hidden flex flex-col h-[500px]"
          >
            {/* Header */}
            <div className={`p-4 text-paper flex items-center justify-between transition-colors duration-300 ${mode === "buyer" ? "bg-accent-buyer" : "bg-accent-supplier"}`}>
              <div className="flex items-center gap-2">
                <Bot size={20} />
                <h3 className="font-semibold text-sm">
                  SupplySync AI - {mode === "buyer" ? "Buyer Mode" : "Supplier Mode"}
                </h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-paper/80 hover:text-paper transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Mode Toggle Bar */}
            <div className="bg-stone-100 p-2 border-b border-stone-300 flex justify-center">
              <div className="bg-paper p-1 rounded-full flex items-center shadow-sm border border-stone-300">
                <button 
                  onClick={() => mode !== "buyer" && toggleMode()}
                  className={`px-4 py-1.5 text-xs font-medium rounded-full transition-all duration-300 ${mode === "buyer" ? "bg-accent-buyer text-paper shadow-sm" : "text-graphite-500 hover:text-graphite-900"}`}
                >
                  Buyer Mode
                </button>
                <button 
                  onClick={() => mode !== "supplier" && toggleMode()}
                  className={`px-4 py-1.5 text-xs font-medium rounded-full transition-all duration-300 ${mode === "supplier" ? "bg-accent-supplier text-paper shadow-sm" : "text-graphite-500 hover:text-graphite-900"}`}
                >
                  Supplier Mode
                </button>
              </div>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 bg-paper">
              {activeMessages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm whitespace-pre-wrap ${
                    msg.sender === "user" 
                      ? "bg-graphite-900 text-paper rounded-br-sm" 
                      : "bg-stone-100 text-graphite-900 border border-stone-300 rounded-bl-sm"
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-3 border-t border-stone-300 bg-paper">
              <div className="flex items-center gap-2 bg-stone-100 rounded-full px-4 py-2 border border-stone-300 focus-within:border-graphite-500 transition-colors">
                <input 
                  type="text" 
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask a question..."
                  className="flex-1 bg-transparent border-none outline-none text-sm text-graphite-900 placeholder:text-graphite-500"
                />
                <button 
                  onClick={handleSend}
                  disabled={!inputValue.trim()}
                  className="text-graphite-900 disabled:text-graphite-500 transition-colors hover:text-accent-buyer disabled:hover:text-graphite-500"
                >
                  <Send size={18} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Button */}
      <motion.button 
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-graphite-900 text-paper rounded-full flex items-center justify-center shadow-card-hover hover:bg-graphite-700 transition-colors duration-300 ml-auto"
      >
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
      </motion.button>
    </div>
  );
}
